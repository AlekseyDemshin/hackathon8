## Intro

This is a plugin with custom icon set:

## How to use

- Clone the repo
- Run `npx serve -p 8081` in a terminal window
- Run `npx ngrok http 8081` in another terminal window to run ngrok
- Get https url from _ngrok_ and paste it in `iframe url` in your app settings.
